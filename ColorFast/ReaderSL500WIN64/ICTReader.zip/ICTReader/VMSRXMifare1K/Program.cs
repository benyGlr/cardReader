﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using VMSRXMifare1K;

namespace VMSRXMifare1K
{
    static class Program
    {
        static public Reader reader1 = new Reader();
        static public Reader reader2 = new Reader();
        static public Reader reader3 = new Reader();

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmMain());
        }
    }
}